#include <iostream>

int tab[1000];

void check(int *a)
{
int zmienna;	
	for(int i = 0; i <1000 ; i++)
	{	
		if(tab[i]<=0)
			break;
	
		zmienna = tab[i];
		zmienna*=zmienna;
		for (int j = 0; j <1000 ; j++)
		{
			if(tab[j]<=0)
				break;
			if(zmienna == tab[j])
				std::cout<<tab[i]<<" jest pierwiastkiem liczby " <<tab[j]<<std::endl;
		}
	}
}


int main()
{
int x= 0;
while(std::cin>>tab[x])
{	if(tab[x] <=0)
	break;
	x++;
	
}

check(tab);

std::cout<<"test";

return 0;
}
