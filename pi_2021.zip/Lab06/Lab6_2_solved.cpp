#include <iostream>

int main()
{
char tab[] = {'b','c','x','h','k','g','h','g'};
char *w;

w = tab;

for(int i = 0 ; i<sizeof(tab)/sizeof(char) ; i++)
{
	if(i%2==0)
	{	
		std::cout<<*w<<std::endl;
	}
	w++;
}

w = tab;
int Last = 1;


std::cout<<std::endl;
while (Last<=sizeof(tab)/sizeof(char))
{
	std::cout<<*w<<std::endl;
	w+=Last;
	Last += Last;
}


}
