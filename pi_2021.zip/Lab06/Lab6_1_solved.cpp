#include <iostream>

int dodawanie(int *a,int *b)
{
	return *a+*b;
}
int odejmowanie(int *a, int*b)
{
	return *a-*b;
}


int main()
{
int a = 5, b = 8;
int c = dodawanie(&a,&b);
int d = odejmowanie(&a,&b);

std::cout<<c<<" "<<d<<std::endl;

return 0;
}
