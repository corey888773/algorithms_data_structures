//============================================================================
// Name        : Lab4_5.cpp
// Author      : Michal Grega
// Version     : V1.0
// Copyright   : Copyright AGH 2017
// Description : Variable range example
//============================================================================

#include <iostream>
using namespace std;

int main() {
	int x = 2;

	if (x > 1) {
		int result = x * 2;
	}

	cout << result;

	return 0;
}
