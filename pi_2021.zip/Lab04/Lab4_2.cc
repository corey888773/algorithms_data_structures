//============================================================================
// Name        : Lab4_2.cpp
// Author      : Michal Grega
// Version     : v1
// Copyright   : Copyright AGH 2017
// Description : Example of an if-else statement
//============================================================================

#include <iostream>
using namespace std;

int main() {
//In this exercise you can change only the following four declarations
//and assignments
	int i=0;
	int j=0;
	int k=1;
	int sum=0;

//Do not change code below of this line
	if (i==1) {
		sum+=1;
		cout<<"Suma 1: "<<sum<<endl;
	} else if (j==1) {
		sum+=1;
		cout<<"Suma 2: "<<sum<<endl;
	} else if (k==1) {
		sum+=1;
		cout<<"Suma 3: "<<sum<<endl;
	}

	return 0;
}
