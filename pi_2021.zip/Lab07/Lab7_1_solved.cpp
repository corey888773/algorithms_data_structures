#include <iostream>

struct car
{
int seats;
int displacement;
	
};

int main()
{

car *p = new car;
p->seats = 4;
p->displacement = 1;

std::cout<<"Seats: "<<p->seats<<" displacement: "<<p->displacement<<std::endl;

delete p;
return 0;
}
