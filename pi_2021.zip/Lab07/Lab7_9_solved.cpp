#include <iostream>
#include <math.h>

struct equasion{
	double a;
	double b;
	double c;
	double x1;
	double x2;

};

double delt(double a,double  b,double c)
{	
	return b*b-4*a*c;
}


void quadratic_equation(equasion *eq)
{
double a = eq->a;
double b = eq->b;
double c = eq->c;

	if(delt(a,b,c)>0)
	{
		eq->x1 = ( -b + sqrt(delt(a,b,c)))/ (2*a);
		eq->x2 = ( -b - sqrt(delt(a,b,c)))/ (2*a);	
		std::cout<<delt(a,b,c)<<" "<<sqrt(delt(a,b,c))<<std::endl;
		std::cout<<a<<" "<<b<<" "<<c<<std::endl;
	}
	if(delt(a,b,c)==0)
	{
		eq->x1 = -b/2*a;
		eq->x2 = eq->x1;
	}
	if(delt(a,b,c)<0)
	{
		std::cout<<"brak rozwiazan"<<std::endl;
	}


}

int main()
{
equasion first = {5,0,80};
quadratic_equation(&first);	
std::cout<< first.x1 << " " <<first.x2<<std::endl;


return 0;
}
