#include <iostream>
#include <math.h>


double delt(double a,double  b,double c)
{	
	return b*b-4*a*c;
}

template<class K>
void quadratic_equation(K a, K b, K c)
{
	 
	if(delt(a,b,c)>0)
	{
		double x1 =( -b + sqrt(delt(a,b,c)))/ 2*a;
		double x2 =( -b - sqrt(delt(a,b,c)))/ 2*a;
		std::cout<<"x1 = "<<x1<<" x2 = "<<x2<<std::endl;	
	}
	if(delt(a,b,c)==0)
	{
		double x = -b/2*a;
		std::cout<<"x = "<<x<<std::endl;
	}
	if(delt(a,b,c)<0)
	{
		std::cout<<"brak rozwiazan"<<std::endl;
	}


}

int main()
{
quadratic_equation(1,0,3);	

return 0;
}
