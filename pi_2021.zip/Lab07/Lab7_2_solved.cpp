#include <iostream>
#include <time.h>

int main()
{
srand(time(NULL));

int size;
std::cin>>size;

int *p = new int[size];

for (int i = 0 ; i < size ; i++)
       	{
	p[i] = rand() % 100;
	std::cout << p[i] << std::endl;	
	}
delete []p;
return 0;	
}
