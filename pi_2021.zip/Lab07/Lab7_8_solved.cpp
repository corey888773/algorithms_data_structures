#include <iostream>

int clipping(int x)
{
	if (x<10)
		return 10;
	if (x>20)
		return 20;
	else
		return x;
}

int main()
{
	std::cout<<clipping(7);
}
