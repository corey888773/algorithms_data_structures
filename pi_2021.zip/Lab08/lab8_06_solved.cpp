#include <iostream>

using namespace std;

class vector2d{
public:
    vector2d(int x, int y){
        cords = new int[2];
        cords[0] = x;
        cords[1] = y;
    }

    void print2d(){
        cout << "x: " << cords[0] << " y: " << cords[1] << endl;
    }

    void add(vector2d *vector){
        cords[0] += vector->cords[0];
        cords[1] += vector->cords[1];
    }

    void set2d(int x, int y){
        cords[0] = x;
        cords[1] = y;
    }
    int get(int i){
        return *(cords+i);
    }

private:
    int *cords;
};

int main()
{
    vector2d v1(3, 5);
    vector2d v2(4, 7);
    v1.print2d();
    v2.print2d();
    v1.add(&v2);
    v1.print2d();
    cout << v1.get(0);

}

