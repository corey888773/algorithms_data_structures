#include <iostream>

using namespace std;


int main(int argc, const char *argv[]) {
    //tworzenie wskaznika na tablice i dynamiczna alokacja pamięci

    if (argv[1] == string("-l")) {
        cout << "File list";
        return 0;
    } else
        cout << "-l - list files" << endl;

    return 0;
}
