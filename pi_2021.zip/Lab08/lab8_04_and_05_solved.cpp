#include <iostream>

using namespace std;

class vector2d{
public:
    vector2d(int x, int y){
        x_ = x;
        y_ = y;
    }

    void print2d(){
        cout << "x: " << x_ << " y: " << y_ << endl;
    }

    void add(vector2d *vector){
        x_ += vector->x_;
        y_ += vector->y_;
    }

    void set2d(int x, int y){
        x_ = x;
        y_ = y;
    }
    int get(char flag){
        if (flag == 'x')
        { return x_; }
        if (flag == 'y')
        { return y_; }
    }

private:
    int x_;
    int y_;
};

int main()
{
    vector2d v1(3, 5);
    vector2d v2(4, 7);
    v1.print2d();
    v2.print2d();
    v1.add(&v2);
    v1.print2d();
    cout << v1.get('x');

}

