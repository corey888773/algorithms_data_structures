#include <iostream>

#define mmax(x, y) (((int)((x)<(y)) * (y)) + ((int)((y)<=(x)) * (x)))
using namespace std;


int main(int argc, const char *argv[]) {
    //tworzenie wskaznika na tablice i dynamiczna alokacja pamięci
//    int a = 5, b = 10;
    int a = *argv[1] - '0';
    int b = *argv[2] - '0';
cout << "a = " << a << " b = " << b << " max = " << mmax(a, b) << endl;

    return 0;
}
