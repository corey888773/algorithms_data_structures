#include <iostream>
using namespace std;

class Board{
private:
    char **board_;
public:
    Board(){
        board_ = new char * [3];
        for (int i = 0; i < 3; i++){
            board_[i] = new char[3];
        }
    }
    void printBoard(){
        for (int i = 0; i < 3; i++){
            for (int j = 0; j < 3; j++)
            {
                cout << board_[i][j] << " ";
            }cout << "\n";
        }
        cout << "\n";
    }
    void Play(int x, int y, char p){
        begining:
        cout << "wybierz pole" << endl;
        cin >> x >> y;
        if (board_[x - 1][y - 1] == (char)0){
            this->move(x, y, p);
        }
        else{
            cout << "wybrales zle pole" << endl;
            goto begining;}

    }
    void move(int x, int y, char p){
            board_[x - 1][y - 1] = p;
            this->printBoard();

    }
    bool checkForWinner(){
        bool win = false;
        int i = 0;
        while(win == false){

                if((board_[i][0] == board_[i][1]) && (board_[i][0] == board_[i][2]) && (board_[i][0] != char(0)))  {
                    win = true;
                    break;
                }
                else if((board_[0][i] == board_[1][i]) && (board_[0][i] == board_[2][i])&& (board_[0][i] != (char)0)) {
                    win = true;
                    break;
                }
                else if((board_[0][0] == board_[1][1]) && (board_[0][0] == board_[2][2])&& (board_[0][0] != (char)0)) {
                    win = true;
                    break;
                }
                else if((board_[0][2] == board_[1][1]) && (board_[0][2] == board_[2][0])&& (board_[2][0] != (char)0)) {
                    win = true;
                    break;
                }
                i ++;
                if (i == 3) break;
        }
        return win;
    }
};

void swapPlayer(int round, char *p){
    if (round % 2 == 0)
        *p = 'x';
    else
        *p = 'o';
}


int main(){
    int round = 0;
    int x, y;
    char PLAYER;
    Board tictac;
    tictac.printBoard();

    while (tictac.checkForWinner() == false){
        swapPlayer(round, &PLAYER);
        tictac.Play(x, y, PLAYER);
        round ++;
    }
cout << "zwyciestwo gracza : " << PLAYER;
}