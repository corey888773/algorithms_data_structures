//============================================================================
// Name        : Lab1.cpp
// Author      : Lucjan Janowski
// Version     : v1.0
// Copyright   : Copyright AGH 2017
// Description : Example on array iteration
//============================================================================

#include <iostream>
using namespace std;

int main() {
  int tab1[] = {1, 2, 3, 5, 8};
  int tab2[] = {1,2,3,4,69,6,7,8};
int i = 0,j = 0;
  

cout<<"pierwsza tablica\n";
	while(tab1[i])
	  {
	  cout<<"id: "<<i<<" wartosc: "<<tab1[i]<<"\n";
	  	i++;
	  	if(i >4)
			break;
	  }
cout<<"druga tablica\n";
	while(tab2[j])
	  {
	  cout<<"id: "<<j<<" wartosc: "<<tab2[j]<<"\n";
	  	j++;
		if (j>7)
			break;
	  }

  return 0;
}

