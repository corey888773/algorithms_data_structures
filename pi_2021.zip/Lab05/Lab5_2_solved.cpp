#include <iostream>

int main()
{int k =0;
	int tab_kwadraty[10];
	int tab1[] = {1, 5, 3, 10};
	int size_kwadraty = sizeof(tab_kwadraty)/sizeof(int);
	int size_tab1 = sizeof(tab1)/sizeof(int);
	for (int i =1; i<=size_kwadraty;i++)
	{
		tab_kwadraty[i-1] = i*i;
		
	}

	for (int j =0;j<size_tab1;j++)
	{
		std::cout<<tab_kwadraty[tab1[j]-1]<<std::endl;

	}
return 0;
}
