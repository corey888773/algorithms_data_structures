#include <iostream>

struct kot
{
	int wiek;
	char kolor;

};

int main()
{
int tab1[] = {1,3,3,4};
double tab2[] ={3.5,7.4,-3.2,-1.2};
kot tofik = {5,'c'};
int *w_tab1;
double *w_tab2;
kot *w_struct;

for(int i=0;i<4;i++)
{
w_tab1 = &tab1[i];
	std::cout<<"adres : " << w_tab1 << "\twartosc : " <<*w_tab1 <<std::endl;
}
std::cout<<std::endl;
for(int i=0;i<4;i++)
{
w_tab2 = &tab2[i];
	std::cout<<"adres : " << w_tab2 << "\twartosc : " <<*w_tab2 <<std::endl;
}
std::cout<<std::endl;
for(int i=0;i<2;i++)
w_struct = &tofik;
	std::cout<<"adres : " << w_struct << "\twartosc : " <<w_struct->wiek<<" "<<w_struct->kolor<<std::endl;
	
return 0;
}
