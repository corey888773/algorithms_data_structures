#include <iostream>

int main()
{
char tab[] = {"Michal Aniol"};
bool x = false;
char* w;
w = tab;

std::cout<<std::endl;
for (int i =0; i<sizeof(tab)/sizeof(char);i++)
{
	std::cout<< *w ;
	w++;
}
w = tab;
std::cout<<std::endl;
for (int j =0; j<sizeof(tab)/sizeof(char);j++)
{
	
	if( x == true)
	{
		std::cout << *w;
	}
	if (*w ==' ')
	{
		x = true;
	}
	w++;
}
return 0;
}
