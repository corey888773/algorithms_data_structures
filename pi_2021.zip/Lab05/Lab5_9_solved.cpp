#include <iostream>
#include <time.h>

int main()
{
//srand(time(NULL));
int a = 5;
int *w;
w = &a;

std::cout<< "\nwartosc a przed zmiana : " << *w <<"\n";

*w = 10;

std::cout<< "\nwartos a po zmianie : " << *w <<"\n";
return 0;
}

