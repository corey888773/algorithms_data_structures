#include <iostream>



void swap(char *a,char *b)
{
char x;	
x = *a;
*a = *b;
*b = x;
}

void perm(std::string ciag,int pivot  = 0)
{
	if (pivot == ciag.length()) 
	{
		std::cout << ciag <<std::endl;
	}
	else
	{
		for (int i = pivot; i < ciag.length(); i++)
		{
		swap(&ciag[i],&ciag[pivot]);
		perm(ciag, pivot + 1);
		swap(&ciag[i],&ciag[pivot]);

		}				
	}
}

int main()
{
std::string ciag;

std::cin>>ciag;
perm(ciag);

return 0;
}
