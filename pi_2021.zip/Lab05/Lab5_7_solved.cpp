//============================================================================
// Name        : Lab7.cpp
// Author      : Lucjan Janowski
// Version     : v1.0
// Copyright   : Copyright AGH 2017
// Description : Example on addressing
//============================================================================

#include <iostream>
using namespace std;

int main() {
  int tab[2] = {3, 7};

cout << &tab[0]<< " -to adres komorki w ktorej znajduje sie pierwszy element tablicy" << endl;
cout << &tab[1]<< " -to adres komorki w ktorej znajduje sie drugi element tablicy" << endl;
cout << "oba adresy zapisane sa w systemie szestnastkowym, a wartosc skoku wynosi tyle ile bitow zajmuje dany typ zmiennej czyl np dla int = 4\n";

cout<< tab[0] << " " << tab[1] <<  "tablica int\n";

double tab1[2] ={3,7};
cout <<"\nadresy tablicy typu double\n";
cout << &tab1[0] <<"\n";
cout << &tab1[1] <<"\n";

void *w;
char tab2[2] = {3,7};
w = tab2;
cout <<"\nadresy tablicy typu char\n";
cout << w << "\n";
cout << w+1 << "\n";

  return 0;
}
