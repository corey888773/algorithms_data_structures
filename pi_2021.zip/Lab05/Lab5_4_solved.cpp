#include <iostream>

int main()
{
int tabliczka[10][10];

for(int i=0;i<10;i++)
{
	for(int j=0;j<10;j++)
	{
		tabliczka[i][j]= (i+1)*(j+1);
		std::cout<<tabliczka[i][j]<<"\t";
	}
	std::cout<<"\n";
}
return 0;
}
