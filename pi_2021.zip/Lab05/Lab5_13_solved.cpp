#include <iostream>

struct struktura
{
	int a;
	int b;
};

int main()
{	
int tabela1[] = {1,2,3,4};
double tabela2[] = {0.5,1.5,2.5,3.5};
struktura s1 = {5,15};
struktura s2 = {2,2137};
int *w_tab1, *w_tab11;
double *w_tab2, *w_tab22;
struktura *w_s1,*w_s2;

std::cout<<std::endl;

for(int i = 0; i<2; i++)
{
	int x; //zmienna pomocnicza
	w_tab1 = &tabela1[i];
	w_tab11 = &tabela1[3-i];

	x = *w_tab1;
	*w_tab1 = *w_tab11;
	*w_tab11 = x;
}
for(int i = 0; i<2; i++)
{
	double x; // zmienna pomocnicza	
	w_tab2 = &tabela2[i];
	w_tab22 = &tabela2[3-i];

	x = *w_tab2;
	*w_tab2 = *w_tab22;
	*w_tab22 = x;
}
////////////////////////////
w_s1 = &s1;
w_s2 = &s2;
*w_s1 = *w_s2;


////////////////////////////

for(int i = 0; i<4; i++)
{
	std::cout<<tabela2[i]<<std::endl;

}
return 0;
}
