#include <iostream>
#include <time.h>
int main()
{
	int tab[] = {1,3,5,9};

//suma
double suma = 0;
for(int i = 0;i<sizeof(tab)/sizeof(int);i++)
{
//	std::cout<<tab[i]<<std::endl;
	suma+=tab[i];
//	std::cout<<suma<<std::endl;
}

//srednia
double srednia = suma/(sizeof(tab)/sizeof(int));

//minimum
int min = tab[0];

for(int i=1; i<sizeof(tab)/sizeof(int);i++)
{
	if(tab[i]<min)
		min=tab[i];
}

//maksimum
int max = tab[0];
for(int i=1; i<sizeof(tab)/sizeof(int);i++)
{
	if(tab[i]>max)
		max=tab[i];
}

std::cout<<"suma :"<<suma<<std::endl;
std::cout<<"srednia :"<<srednia<<std::endl;
std::cout<<"minimum :"<<min<<std::endl;
std::cout<<"maksimun :"<<max<<std::endl;

return 0;
}
