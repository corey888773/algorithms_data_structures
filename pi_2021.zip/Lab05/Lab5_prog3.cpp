#include <iostream>
#include <time.h>

void swap (int *a, int *b, int x=0)
{
	x=*a;
	*a=*b;
	*b=x;
}

void sortuj(int *tab)
{
int x = 9;
	for (int i = 0; i < 10 ; i++)
	{	for(int j =0; j<(9-i);j++)
		{
			if(tab[j]>tab[j+1])	
			{
				swap(&tab[j],&tab[j+1]);
			}
		}
	}
}

int main()
{
srand(time(NULL));
int tab[10] = {};


for(int i = 0; i<10; i++)
{
	tab[i] = rand() % 100;
	std::cout <<tab[i] <<" ";
}

std::cout<<std::endl<<std::endl;

sortuj(tab);
for(int i = 0; i<10; i++)
{	
	std::cout <<tab[i] <<" ";
}


return 0;

}
