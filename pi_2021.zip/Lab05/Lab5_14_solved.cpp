#include <iostream>

int main()
{
int tab[][];	
tab[3][] = {8,5,3,9};



return 0;
}
