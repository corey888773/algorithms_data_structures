//============================================================================
// Name        : Lab8.cpp
// Author      : Lucjan Janowski
// Version     : v1.0
// Copyright   : Copyright AGH 2017
// Description : Example on reference and dereference
//============================================================================

#include <iostream>


int main() {
  int *x;
  int y = 2;

  x = &y; // adres zmiennej
	
//x = y; // bledne
//*x = y; //bledne
//*x = &y;

  std::cout<<"wartosc zmiennej : " <<y <<"\n";
  std::cout<<"adres zmiennej : " << &y <<"\n";
  std::cout<<"adres wskazywany przez wskaznik : " << x << "\n";
  std::cout<<"wartosc wskaznika : " << *x << "\n";
  return 0;
}
