#include <iostream>
#include <time.h>
void swap(int *a,int *b,int x = 0)
{
x = *a;
*a = *b;
*b = x;
}

int main()
{
//zapewnia losowosc
srand(time(NULL));

int tab[] = {};
int a,b;

for (int i = 0 ; i<10 ; i++)
{
	tab[i] = rand () % 100;
	std::cout<<tab[i]<<std::endl;
}

wybor:
std::cout << "\nPodaj 2 numery indeksow (od 0 do 9), ktore zostana zamienione " << std::endl;
std::cin>>a>>b;

if((0>a||a>9)||(0>b||b>9))
{
	std::cout<<"==========="<<std::endl;
	std::cout<<"bledne dane"<<std::endl;
	std::cout<<"==========="<<std::endl;
	
	goto wybor;
}
else
{
	swap(&tab[a],&tab[b]);

	for(int i = 0; i <10; i++)
	{
		std::cout<<tab[i]<<std::endl;
	}
}
return 0;
}
