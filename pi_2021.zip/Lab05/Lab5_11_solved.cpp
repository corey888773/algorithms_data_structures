#include <iostream>

int main()
{
int tab[10] = {1,2,3,4,5,6,7,8,9,10};
int *w;

for(int i=0;i<100;i++)
{
	w=&tab[i];
	std::cout <<*w<<"\n";
	
}
 return 0;

}
