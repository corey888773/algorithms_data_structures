
#include <iostream>
using namespace std;

//To jest komentaż do tego pliku. Ten plik jest ewidentnie źle fsormatowany i należy to koniecznie poprawić, pamiętając o nazwach zmiennych
//dopuszczalnej długości linii, znakach z kodu ANSI, wcięciach i dbalości o wsykoiehj jakosci kometarze

int main() { int PierwszaZmienna=5; int Drugazmienna=7;
int WynikDziałania=PierwszaZmienna+Drugazmienna;

cout <<"Wynik Dodawania Dwóch Liczb To:"<<WynikDziałania<<endl; // Wypisuje wynik dzialania
return 0;
}
