#include <iostream>
#include <cstring>
using namespace std;

class Vector{
public:
    double *data_;
    Vector(double data){
        data_=new double;
        *data_=data;
    }
    ~Vector(){
        delete data_;
    }
    //referencja
    double add1(Vector &arg){
        cout<<"dodaje referencja\n";
        cout<<"adres data_:\t"<<data_<<endl;
        cout<<"adres arg.data_;"<<arg.data_<<endl;
        return *data_+(*(arg.data_));
    }

    //wskaznik
    double add2(Vector *arg){
        cout<<"\ndodaje wskaznikami\n";
        cout<<"adres data_:\t"<<data_<<endl;
        cout<<"adres arg.data_;"<<arg->data_<<endl;
        return *data_+(*(arg->data_));
    }


    //konstruktor kopiujacy
    Vector(const Vector &copy){
        data_=new double;
        memcpy(data_,copy.data_, sizeof(double));
    }

    double add3(Vector arg){
        cout<<"\ndodaje konstruktorem kopiujacym\n";
        cout<<"adres data_:\t"<<data_<<endl;
        cout<<"adres arg.data_;"<<arg.data_<<endl;
        return *data_+*(arg.data_);
    }
};

int main(){
    Vector v1(2.0);
    Vector v2(3.0);
    v1.add1(v2);
    v1.add2(&v2);
    v1.add3(v2);

    return 0;
}
