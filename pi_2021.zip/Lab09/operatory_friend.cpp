#include <iostream>
// #1 PRZECIĄZENIE OPERATORÓW
// #2 ZASTOSOWANIE PRZECIAZENIA WEWNATRZ JAK I NA ZEWNATRZ KLASS
// #3 FUNKCJA FRIEND
// #4
using namespace std;

class Vec{
public:
    Vec(int x, int y){
        this->x_ = x;
        this->y_ = y;
    }
    Vec(){}

    Vec operator+(const Vec &secondVec){
        Vec result;
        result.x_ = this->x_ + secondVec.x_;
        result.y_ = this->y_ + secondVec.y_;
        return result;
    }
    friend Vec operator*(const Vec& first, const Vec& second);
    friend ostream &operator<<(ostream &out, const Vec& vector);
    friend void reverse(Vec &vec);

private:
    int x_;
    int y_;
};

Vec operator*(const Vec& first, const Vec& second){
    Vec result;
    result.x_ = first.x_ * second.x_;
    result.y_ = first.y_ * second.y_;
    return result;
}

ostream &operator<<(ostream &out, const Vec& vector){
    out << vector.x_ << " : ";
    out << vector.y_ << endl;
    return out;
}

void reverse(Vec &vec){
    vec.x_ *= -1;
    vec.y_ *= -1;
}

int main() {
    Vec v1(3, 5);
    Vec v2(4, -2);

    Vec v3 = v1 + v2;
    Vec v4 = v3.operator+(v2);
    Vec v5 = v4 * v1;
    Vec v6 = operator*(v4, v2);

//    cout << v3.x_ << " : " << v3.y_ << endl;
//    cout << v4.x_ << " : " << v4.y_ << endl;
//    cout << v5.x_ << " : " << v5.y_ << endl;
    cout << v6;

}
