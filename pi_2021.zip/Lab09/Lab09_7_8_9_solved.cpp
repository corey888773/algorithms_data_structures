#include <iostream>
#include <cstring>


using namespace std;

class CD {
public:
    CD(char *content) {
        strcpy(this->content_, content);
        this->in_ = true;
    }

    CD() {this->in_ = true;}

    char read() {
        if(in_) {
            cout << endl;
            for (auto &&i: content_) {
                cout << i << "\t";
            }
        }
    }
    void in_out() {
        this->in_ = !this->in_;
    }
protected:
    char content_[10];
    bool in_ = true;

};

class CDRW : public CD {
public:
    void write(const char *content1){
        if (in_){
            for (char &i : content_){
                i = *content1;

            }
        }
    }
};

class BR : public CDRW {
protected:
    char content[20];
};

int main() {
char kontent1[10] = {'a','a','a','a','a','a','a','a','a','a'};
char kontent2[10] = {'b','b','b','b','b','b','b','b','b','b'};
    CD c1(kontent1);
    CDRW c2;
    c1.read();
    c2.write(kontent2);
    c2.in_out();
    c2.read();
    c2.in_out();
    c2.read();
}
