#include <iostream>
using namespace std;

class Vector{
private:
    double *data_;
public:
    Vector(double data){
        data_=new double;
        *data_=data;
    }
    ~Vector(){
        delete data_;
    }
    double add(Vector &arg){
        return *data_+(*(arg.data_));
    }
};

int main(){
    Vector v1(2.0);
    Vector v2(3.0);
    cout<<v1.add(v2)<<endl;
    return 0;
}
