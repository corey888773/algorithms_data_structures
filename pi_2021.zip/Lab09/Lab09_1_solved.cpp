#include <iostream>
using namespace std;

class Time{
private:
    long int min_;
public:
    Time(long int min){
        this->min_ = min;
    }
    Time(int hour, int min){
        min_ = 60 * hour + min;
    }
    Time(string hour){
        min_=600*(int(hour[0])-'0');
        min_+=60*(int(hour[1])-'0');
        min_+=10*(int(hour[3])-'0');
        min_+=(int(hour[4])-'0');
    }
    void print(){
        cout<<min_<<endl;
    }

};


int main() {
    Time t1(123);
    Time t2(12, 45);
    Time t3("12:23");
    t1.print();
    t2.print();
    t3.print();
    return 0;
}