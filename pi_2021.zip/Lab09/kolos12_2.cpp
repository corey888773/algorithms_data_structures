#include <iostream>
#include <time.h>

using namespace std;

class Clothing{
private:
    int volume_;
    int weight_;

public:
    Clothing(int volume, int weight){
        this->weight_ = weight;
        this->volume_ = volume;
    }
    Clothing(){

    };
    int getWeight(){
        return weight_;
    }
    int getVolume(){
        return volume_;
    }
    void setWeight(int weight){
        this->weight_ = weight;
    }
    void setVolume(int volume){
        this->volume_ = volume;
    }
};

class Suitcase{
private:
    int weight_ = 0;
    int capacity_;

public:
    Suitcase(int capacity){
        this->capacity_ = capacity;
    }

    bool Put_in(Clothing &cloth){
    if(this->capacity_ > cloth.getVolume()) {
        cout << "ubranie wlozone do walizki" << endl;
        this->weight_ += cloth.getWeight();
        this->capacity_ -= cloth.getVolume();
        return true;
    }else{
        cout << "nie udalo sie wlozyc ubrania do walizki" << endl;
        return false;
       }
    }

    void Put_in_array(Clothing tab[]){
        for(int i = 0 ; i < 10 ; i++){
            if (this->Put_in(tab[i])) {
                cout << "ubranie nr " << i << endl;
                cout << "waga: " << this->weight_ << " objetosc: " << this->capacity_ << endl;
            }
        }
    }
};

int main() {
    srand(time(NULL));

    Suitcase s1(20);

    Clothing *array = new Clothing[10];

    for (int i = 0; i < 10; i++) {
        array[i].setVolume((rand() % 5) + 1);
        array[i].setWeight(rand() % 5);
        cout << "ubranie : " << i << " ,objetosc : " << array[i].getVolume() << " ,waga : " << array[i].getWeight()
             << endl;


    }
    s1.Put_in_array(array);
    delete[] array;
}

