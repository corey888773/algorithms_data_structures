#include <iostream>

using namespace std;

class Unit{
private:
    int HP_;
public:
    Unit(int HP){
        this->HP_ = HP;
    }
    Unit(){
        this->HP_ = 50;

    }
    int getHP(){
       return HP_ ;
    }
};

class ERK : public Unit{
private:
    double gathering_speed_;
public:
    ERK(double gathering_speed, int HP) : Unit(HP){
        this->gathering_speed_ = gathering_speed;
    }
    void print_stats(){
        cout << "Unit ERK -> HP: " << this->getHP() << ", gathering speed: " << this->gathering_speed_ << endl;
        cout << "======================================================"<< endl;
    }
    void set_gathering_speed(double gathering_speed){
        this->gathering_speed_ = gathering_speed;
    }
    double get_gathering_speed(){
        return gathering_speed_;
    }
};

class Crow : public Unit{
private:
    double energy_;
public:
    Crow(double energy, int HP): Unit(HP){
        this->energy_ = energy;
    }
    void speed_up(ERK &erk){
        this->set_energy(this->get_energy()/2);
        erk.set_gathering_speed(erk.get_gathering_speed()*2) ;
    }
    void print_stats(){
        cout << "Unit Crow -> HP: " << this->getHP() << ", energy: " << this->energy_ << endl;
        cout << "======================================================"<< endl;
    }
    double get_energy(){
        return this->energy_;
    }
    void set_energy(double energy){
        this->energy_ = energy;
    }
};
int main(){
    Crow c1( 50 , 100);
    ERK e1(5 , 75);
    c1.print_stats();
    e1.print_stats();
    c1.speed_up(e1);
    c1.print_stats();
    e1.print_stats();

}