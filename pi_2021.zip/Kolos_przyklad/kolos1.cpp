#include <iostream>
#include <time.h>
struct stat
{
	int min;
	int max;
	double mean;
};

void function(int *tab, stat *stat, int size)
{
	int max = tab[0];
	int min = tab[0];
	double sum = tab[0];

	for (int i = 1; i < size ; i++)
	{
		if (tab[i]>max)
			max = tab[i];
		if (tab[i]<min)
			min = tab[i];
		sum+= tab[i];
	}
	
	stat->max = max;
	stat->min = min;
	stat->mean = sum/size;
}
void wyswietl_tab(int *tab, int size)
{
	for(int i = 0 ; i<size ; i++)
	{
		std::cout<< tab[i] << " ";
	}
	std::cout<<"\n";
}
void wyswietl_struct(stat *stat)
{
	std::cout<< std::endl << "max : " << stat->max << "  min : " << stat->min << "  mean : " << stat->mean << std::endl;
}
void polacz(int *tab1, int *tab2,stat *stat,int size)
{
	int *tabS = new int[size*2];
	
	for (int i = 0; i < size; i++)
	{
		tabS[i] = tab1[i];
		tabS[i+size] = tab2[i];
	}
	wyswietl_tab(tabS,size*2);
	function(tabS,stat,size*2);
	wyswietl_struct(stat);
	
	delete []tabS;
}

int main()
{	srand(time(NULL));
	
	stat tab1_stat;
	stat tab12_stat;
	int size;
	std::cin>>size;

	int tab1[size];
	int tab2[size];
	int tab3[size*2];
	for (int i = 0; i < size ; i++)
	{
		tab1[i] = rand() % 20;
		tab2[i] = rand() % 20;
	}	
	
	function(tab1,&tab1_stat,size);
	wyswietl_tab(tab1,size);
	wyswietl_tab(tab2,size);
	polacz(tab1,tab2,&tab12_stat,size);

	return 0;
}
