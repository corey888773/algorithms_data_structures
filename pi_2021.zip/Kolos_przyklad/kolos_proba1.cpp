#include <iostream>

//funkcja zmieniajaca zawartosc tablicy
void function(int *tab,int start,int size)
{
	int sum = 0;
	int *w = tab;
	for (int i = 0 ; i<size ; i++)
	{
		if ((i == 0) or (i == 1))
		{ 
			*(w+i) = start;
		}
		else
		{
			*(w+i) = sum; 
		}
	sum += tab[i];
	}	
}
//funkcja wyswietlajaca zawartosc tablicy
void show(int *tab, int size)
{
	for (int i = 0 ; i < size ; i++ )
	{
		std::cout<< tab[i] << "\t";
	}
	std::cout << "\n";
}
int main()
{
//definicja zmiennych	
	int size, start;
//wprowadzanie zmiennych
	std::cout << "Podaj rozmiar tablicy" << std::endl;
	std::cin >> size;
	std::cout << "Podaj poczatkowa wartosc tablicy" << std::endl;
	std::cin >> start;
//alokacja pamieci dla tablicy
	int *tab = new int[size];
//wyswietlanie obu tablic	
	show(tab , size);
	function(tab, start, size);
	show(tab , size);
	
	delete []tab ;

return 0;
}
